﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GMap.NET;
using GMap.NET.MapProviders;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            GeoCoderStatusCode status;
            string address = "";
            Placemark pos = (Placemark)GMapProviders.GoogleMap.GetPlacemark(new PointLatLng(40.4258333, -86.9080556),out status);
            if (status == GeoCoderStatusCode.G_GEO_SUCCESS)
            {
                address = pos.Address;
                Console.WriteLine(address);
            }

        }
    }
}
