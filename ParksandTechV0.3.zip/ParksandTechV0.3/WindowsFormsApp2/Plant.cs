﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Plant : Form
    {
        public Plant()
        {
            InitializeComponent();
        }

        private void btnMoreInfo_Click(object sender, EventArgs e)
        {
           
        }

        private void btnPoisonInformation_Click(object sender, EventArgs e)
        {
            Hide();
            new PoisonInformation().Show();
        }

        private void btnEdibleInformation_Click(object sender, EventArgs e)
        {
            Hide();
            new EdibleInformation().Show();
        }
    }
}
