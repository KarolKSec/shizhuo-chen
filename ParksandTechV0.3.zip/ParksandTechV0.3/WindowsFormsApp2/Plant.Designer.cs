﻿namespace WindowsFormsApp2
{
    partial class Plant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkboxPoison = new System.Windows.Forms.CheckBox();
            this.btnPoisonInformation = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.chkboxEdible = new System.Windows.Forms.CheckBox();
            this.btnEdibleInformation = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Plants Found on This Trail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(277, 37);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(171, 132);
            this.listBox1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(22, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 154);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Description";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 6;
            // 
            // chkboxPoison
            // 
            this.chkboxPoison.AutoSize = true;
            this.chkboxPoison.Enabled = false;
            this.chkboxPoison.Location = new System.Drawing.Point(22, 344);
            this.chkboxPoison.Name = "chkboxPoison";
            this.chkboxPoison.Size = new System.Drawing.Size(104, 21);
            this.chkboxPoison.TabIndex = 1;
            this.chkboxPoison.Text = "Poisonous?";
            this.chkboxPoison.UseVisualStyleBackColor = true;
            // 
            // btnPoisonInformation
            // 
            this.btnPoisonInformation.Enabled = false;
            this.btnPoisonInformation.Location = new System.Drawing.Point(132, 342);
            this.btnPoisonInformation.Name = "btnPoisonInformation";
            this.btnPoisonInformation.Size = new System.Drawing.Size(131, 23);
            this.btnPoisonInformation.TabIndex = 7;
            this.btnPoisonInformation.Text = "More Information";
            this.btnPoisonInformation.UseVisualStyleBackColor = true;
            this.btnPoisonInformation.Click += new System.EventHandler(this.btnPoisonInformation_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(18, 219);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(437, 119);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "";
            // 
            // chkboxEdible
            // 
            this.chkboxEdible.AutoSize = true;
            this.chkboxEdible.Enabled = false;
            this.chkboxEdible.Location = new System.Drawing.Point(21, 372);
            this.chkboxEdible.Name = "chkboxEdible";
            this.chkboxEdible.Size = new System.Drawing.Size(77, 21);
            this.chkboxEdible.TabIndex = 10;
            this.chkboxEdible.Text = "Edible?";
            this.chkboxEdible.UseVisualStyleBackColor = true;
            // 
            // btnEdibleInformation
            // 
            this.btnEdibleInformation.Enabled = false;
            this.btnEdibleInformation.Location = new System.Drawing.Point(132, 372);
            this.btnEdibleInformation.Name = "btnEdibleInformation";
            this.btnEdibleInformation.Size = new System.Drawing.Size(131, 24);
            this.btnEdibleInformation.TabIndex = 11;
            this.btnEdibleInformation.Text = "More Information";
            this.btnEdibleInformation.UseVisualStyleBackColor = true;
            this.btnEdibleInformation.Click += new System.EventHandler(this.btnEdibleInformation_Click);
            // 
            // Plant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 508);
            this.Controls.Add(this.btnEdibleInformation);
            this.Controls.Add(this.chkboxEdible);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnPoisonInformation);
            this.Controls.Add(this.chkboxPoison);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Plant";
            this.Text = "Plant";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkboxPoison;
        private System.Windows.Forms.Button btnPoisonInformation;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.CheckBox chkboxEdible;
        private System.Windows.Forms.Button btnEdibleInformation;
    }
}